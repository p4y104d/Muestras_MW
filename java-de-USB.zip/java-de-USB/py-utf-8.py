import re

def unicode_replace(matchObj):
    #return (matchObj.group().decode('unicode-scape').encode("hex"))
    return (matchObj.group().decode('hex').encode("ascii"))

file = open('/root/Documents/analisis/java-de-USB/original.js','r')
for line in file:
    line=line.strip()
    print re.sub(r'(\\x)+', unicode_replace, line)
